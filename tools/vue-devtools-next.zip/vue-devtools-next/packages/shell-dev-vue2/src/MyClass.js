export default class MyClass {
  constructor () {
    this.msg = 'hi'
  }
}
