<script>
export default {
  devtools: {
    hide: true
  }
}
</script>

<template>
  <div>I'm hidden in the devtools</div>
</template>
